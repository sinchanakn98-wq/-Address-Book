#include<stdio.h>
#include "contact.h"
int main()
{
    int choice;
    Addresbook addresbook;
    //initalize(&addresbook);
loadcontact(&addresbook);
{
    do{
    printf("\n1.for creat contact\n");
    printf("2.for search contact\n");
    printf("3.for Edit a contact\n");
    printf("4.for delet contact\n");
    printf("5.for list contact\n");
    printf("6.for save and exit\n");
    printf("Enter the choice: ");
    scanf("%d",&choice);
    getchar();
    switch (choice)//use a case to chose a option.
    {
        case 1:
        creatcontact(&addresbook);
        break;
        case 2:
        searchcontact(&addresbook);
        break;
        case 3:
        editcontact(&addresbook);
        break;
        case 4:
        deletcontact(&addresbook);
        break;
        case 5:
        listcontact(&addresbook);
        break;
        case 6:
        savecontact(&addresbook);
        printf("Exite...\n");
        break;
        default:
        printf("Enter chose is not valide plese enter agin:");
    }

    }while(choice!=6);//use loop for chose.
    return 0;
}
}
