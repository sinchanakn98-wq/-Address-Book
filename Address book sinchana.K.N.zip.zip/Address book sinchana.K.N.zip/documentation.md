Address Book Management System in C

1. Introduction

The Address Book Management System is a C programming project designed to store and manage contact information. It allows users to create, search, edit, delete, and display contacts.

The project uses structures, functions, arrays, pointers, and file handling to manage contact information.

2. Objectives

The main objectives of this project are:

- To learn structure usage in C.
- To understand functions and pointers.
- To perform contact management operations.
- To validate names, phone numbers, and email addresses.
- To store contact information in a file for future use.

3. Features

The system provides the following features:

1. Create a new contact.
2. Search for an existing contact.
3. Edit contact details.
4. Delete a contact.
5. Display all contacts.
6. Save contact information to a file.
7. Load saved contacts when the program starts.
8. Exit the application.

4. Technologies Used

- Programming language: C
- Header files: stdio.h and string.h, along with any other required headers.
- Data structures: Structures and arrays.
- Storage: File handling.

## 5. Project Files

The project may contain the following files:

- main.c: Contains the main function and menu-driven interface.
- contact.h: Contains structure definitions and function declarations.
-populate.c:Contains functions for creating, searching, editing, deleting, and displaying contacts.
- contact.c: contact list all will print here.
- README.md: Contains the project documentation.

Additional files may be included for saving and loading contacts.

6. Program Execution

When the program starts, it loads previously saved contact information if the data file exists.

The user can select an operation from the menu.

The program performs the selected operation and updates the contact information as required.

When a contact is created, edited, or deleted, the updated information can be saved to a file.

7. Data Storage

The program uses file handling to preserve contact information between executions.

The saving function writes contact records to a file. The loading function reads the saved records and restores them to the address book.

The exact file format depends on the implementation.

8. Sample Menu

1. Create Contact
2. Search Contact
3. Edit Contact
4. Delete Contact
5. List Contacts
6. Exit

9. Advantages

- Makes contact management easier.
- Demonstrates important C programming concepts.
- Allows contact information to be stored persistently.
- Helps develop problem-solving and programming skills.

10. Conclusion

The Address Book Management System demonstrates the practical application of C programming concepts, including structures, arrays, functions, pointers, input validation, and file handling.

The project provides a foundation for developing more advanced record-management applications.