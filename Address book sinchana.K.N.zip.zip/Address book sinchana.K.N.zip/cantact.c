#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include "contact.h"
void  listcontact(Addresbook*addresbook)
{
    int i;
    printf("------------------------------------------------------------------------\n");
    printf("Name\t\t\tNumber\t\t\tEmail\n");
    printf("-------------------------------------------------------------------------\n");
for(i=0;i<addresbook->contactcount;i++)
{
   printf("%s\t\t\t%s\t\t\t%s\n",addresbook->contacts[i].name,addresbook->contacts[i].number,addresbook->contacts[i].email);
}
printf("-------------------------------------------------------------------------\n");
}
void creatcontact(Addresbook*addresbook)
{
  printf("Contact count = %d\n", addresbook->contactcount);
  if (addresbook->contactcount >= CONTACTCOUNT_MAX)//if contct is more the a max contact it printed a error message.
    {
        printf("Contact list is full!\n");
        return;
    }
  while(1)
  {
    printf("Enter the Name: ");
    scanf(" %[^\n]",addresbook->contacts[addresbook->contactcount].name);
   if(validname(addresbook->contacts[addresbook->contactcount].name))//cheak enter name is vaild or not if it not print a error message.
   {
    
     break;
   }
   printf("Please enter name not valid try again \n");
  }
  while(1)
  {
    printf("Enter the Number: ");
    scanf(" %[^\n]",addresbook->contacts[addresbook->contactcount].number);
    if(validnumber(addresbook->contacts[addresbook->contactcount].number,addresbook))//cheak enter number is vaild or not if it not print a error message.
    {
      break;
    }
    printf("Please enter number is not valid try again \n");
  }
  while(1)
  {
    printf("Enter the Email: ");
    scanf(" %[^\n]",addresbook->contacts[addresbook->contactcount].email);
    if(validemail(addresbook->contacts[addresbook->contactcount].email,addresbook))//cheak enter email is vaild or not if it not print a error message.
    {
      break;
    }
    printf("Please enter email not valid try again \n");
  }
  addresbook->contactcount++;

    printf("Contact created successfully!\n");//valid printed.
}
void searchcontact(Addresbook*addresbook)
{
  int choice;
  printf("\n1.Search by name\n");
  printf("2.Search by phone number\n");
  printf("3.search by email\n");
  printf("Enter the choice: ");
  scanf("%d",&choice);
  switch(choice)
  {
  case 1:
  while(1)
  {
    printf("Enter the Name: ");
    scanf(" %[^\n]",addresbook->contacts[addresbook->contactcount].name);
    if(searchname(addresbook->contacts[addresbook->contactcount].name,addresbook))//search a contact if name is not searched printed a error message. 
    {
      break;
    }
    printf("please entered name is not found try again \n");
  }
  break;
 case 2:
 while(1)
 {
  printf("Enter the phone Number:");
  scanf(" %[^\n]",addresbook->contacts[addresbook->contactcount].number);
  if(searchnumber(addresbook->contacts[addresbook->contactcount].number,addresbook))//search a contact if number is not searched printed a error message. 
  {
    break;
  }
   printf("please entered number is not found try again\n");
 } 
 break;
case 3:
while(1)
{
 printf("Enter the Email:");
  scanf(" %[^\n]",addresbook->contacts[addresbook->contactcount].email);
  if(searchemail(addresbook->contacts[addresbook->contactcount].email,addresbook))//search a contact if email is not searched printed a error message. 
  {
    break;
  }
   printf("please entered email is not found try again\n");
 }
 break;
}
}   
void editcontact(Addresbook*addresbook)
{
int choice;
  printf("\n1.Edit by Name\n");
  printf("2.Edit by phone Number\n");
  printf("3.Edit by Email\n");
  printf("Enter the choice: ");
  scanf("%d",&choice);
  switch(choice)
  {
  case 1:
  while(1)
  {
    printf("Enter the Name: ");
    scanf(" %[^\n]",addresbook->contacts[addresbook->contactcount].name);
  if(editname(addresbook->contacts[addresbook->contactcount].name,addresbook))//edit a name if name is not edit it printed a error message.
    {
      break;
    }
    printf("please entered name is not found try again \n");
  }
  break;
 case 2:
 while(1)
 {
  printf("Enter the phone Number:");
  scanf(" %[^\n]",addresbook->contacts[addresbook->contactcount].number);
  if(editnumber(addresbook->contacts[addresbook->contactcount].number,addresbook))//edit a number if name is not edit it printed a error message.
  {
    break;
  }
   printf("please entered number is not found try again\n");
 } 
 break;
 case 3:
 while(1)
 {
  printf("Enter the phone Email:");
  scanf(" %[^\n]",addresbook->contacts[addresbook->contactcount].email);
  if(editemail(addresbook->contacts[addresbook->contactcount].email,addresbook))//edit a email if name is not edit it printed a error message.
  {
    break;
  }
   printf("please entered email is not found try again\n");
 } 
 break;
 }
}
void deletcontact(Addresbook*addresbook)
{
int choice;
  printf("\n1.Delet by Name\n");
  printf("2.Delet by phone Number\n");
  printf("3.Delet by Email\n");
  printf("Enter the choice: ");
  scanf("%d",&choice);
  switch(choice)
  {
  case 1:
  while(1)
  {
    printf("Enter the Name: ");
    scanf(" %[^\n]",addresbook->contacts[addresbook->contactcount].name);
  if(deletname(addresbook->contacts[addresbook->contactcount].name,addresbook))//deleted a contact if contact is not deleted it printed a error message.
    {
      break;
    }
    printf("please entered name is not found try again \n");
  }
  break;
 case 2:
 while(1)
 {
  printf("Enter the phone Number:");
  scanf(" %[^\n]",addresbook->contacts[addresbook->contactcount].number);
  if(deletnumber(addresbook->contacts[addresbook->contactcount].number,addresbook))//deleted a contact if contact is not deleted it printed a error message.
  {
    break;
  }
   printf("please entered number is not found try again\n");
 } 
 break;
 case 3:
 while(1)
 {
  printf("Enter the phone Email:");
  scanf(" %[^\n]",addresbook->contacts[addresbook->contactcount].email);
  if(deletmail(addresbook->contacts[addresbook->contactcount].email,addresbook))//deleted a contact if contact is not deleted it printed a error message.
  {
    break;
  }
   printf("please entered email is not found try again\n");
 } 
 break;
 }
}
