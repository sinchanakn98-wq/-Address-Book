#ifndef CONTACT_H
#define CONTACT_H
#define CONTACTCOUNT_MAX 100
typedef struct //creat a structure to caontact.
{
    char name[100];
    char number[11];
    char email[100];
}contact;
typedef struct
{
   contact contacts[100];
   int contactcount;
}Addresbook;
//function use to creat a addres book.
void loadcontact(Addresbook*addressbook);
void creatcontact(Addresbook*addresbook);
void searchcontact(Addresbook*addresbook);
void editcontact(Addresbook*addresbook);
void deletcontact(Addresbook*addresbook);
void listcontact(Addresbook*addresbook);
void savecontact(Addresbook*addresbook);
//void initalize(Addresbook*addresbook);
int validname(char name[]);
int validnumber(char number[],Addresbook*addresbook);
int validemail(char email[],Addresbook*addresbook);
int searchname(char name[],Addresbook*addresbook);
int searchnumber(char number[],Addresbook*addresbook);
int searchemail(char email[],Addresbook*addresbook);
int editname(char name[],Addresbook*addresbook);
int editnumber(char number[],Addresbook*addresbook);
int editemail(char email[],Addresbook*addresbook);
int deletname(char name[],Addresbook*addresbook);
int deletnumber(char number[],Addresbook*addresbook);
int deletmail(char email[],Addresbook*addresbook);
#endif
