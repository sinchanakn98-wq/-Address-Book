#include<stdio.h>
#include "contact.h"
#include "ctype.h"
#include "string.h"

//static contact damyycontacts[]={
//{"sinchu","9535686799","sin@gmail.com"},
//{"sahana","8989765785","sahana@gmail.com"},
//{"mani","9535875687","mani@gmail.com"},
//{"nagesh","8535673598","nagesh@gmail.com"},
//{"puni","9834567834","puni@gmail.com"},
//{"jyothi","8745231478","jyothi@gmail.com"}};
//void initalize(Addresbook*addresbook)
//{
    //int i;
   //addresbook->contactcount=0;
    //int numofdamyycontacts=sizeof(damyycontacts)/sizeof(damyycontacts[0]);
    //for(i=0;i<numofdamyycontacts&&addresbook->contactcount<100;i++)
    //{
      // addresbook->contacts[addresbook->contactcount++]=damyycontacts[i];
    //}
//}
void loadcontact(Addresbook*addresbook)//To loade a contact to file.
{
    FILE *fp;
    int i;
    fp=fopen("contact.csv","r");
    fscanf(fp,"%d\n",&addresbook->contactcount);
    for(i=0;i<addresbook->contactcount;i++)//loded a caontent by usenig for loop unitile the contact count.
    {
        fscanf(fp," %[^,], %[^,], %[^\n]",addresbook->contacts[i].name,addresbook->contacts[i].number,addresbook->contacts[i].email);
    }
}
int validname(char name[])
{
    int i=0;
    for(i=0;name[i]!='\0';i++)
    {
    if(!isalpha((unsigned char)name[i]) || name[i]==' ')//cheak a give name is alphabet are not.
    {
        return 0;
    }
    }
    while(name[i]!='\0')
    {
        name[i]=tolower((unsigned char)name[i]);//convert the upper case alphabet to lowercase.

        i++;
    }
    return 1;
}
int validnumber(char number[],Addresbook*addresbook)
{
    int i=0;
    if(strlen(number)!=10)//cheak the give number lenth is 10 are it above 10 give an error message.
    {
        return 0;
    }
    for(i=0;number[i]!='\0';i++)
    {
    if(!isdigit((unsigned char)number[i]))//cheak the give number is digit or not.
    {
        return 0;
    }
    }
    for(i=0;i<addresbook->contactcount;i++)
    {
        if(strcmp(number,addresbook->contacts[i].number)==0)//camper the given number is different form othe number if number is same as other number it print a error message.
        {
            return 0;
        }
    }
    return 1;
}
int validemail(char email[],Addresbook*addresbook)
{
    int i=0;
  for(i=0;email[i]!='\0';i++)
  {
    if(isdigit((unsigned char)email[i]))//cheak the given email is contain digit or not if it  contain  digit print error message.
    {
        return 0;
    }
  }
   for(i=0;email[i]!='\0';i++)
   {
         if(isspace((unsigned char)email[i]))//chek email contain space or not.
        {
            return 0;
        }
    }
  for(i=0;email[i]!='\0';i++)
    {
        email[i]=tolower((unsigned char)email[i]);//coverted to lower case.
    }
    int at=-1,dot=-1;
    for(i=0;email[i]!='\0';i++)//cheak given email valid or not.
    {
        if(isspace((unsigned char)email[i]))
        {
            return 0;
        }
        if(email[i]=='@')
        {
            if(at!=-1)
            {
                return 0;
            }
            at=i;
        }
    }
    if(at<=0)
    {
        return 0;
    }
    for(i=at+1;email[i]!='\0';i++)
    {
        if(isspace((unsigned char)email[i]))
        {
            return 0;
        }
        if(email[i]=='.')
        {
            dot=i;
        }
    }
    if(dot<=at+1)
    {
        return 0;
    }
    if(email[dot+1]=='\0')
    {
        return 0;
    }
    for(i=0;i<addresbook->contactcount;i++)
    {
        if(strcmp(email,addresbook->contacts[i].email)==0)//camper the given email is alread there if it there print error message.
        {
            return 0;
        }
    }
    return 1;
}
int searchname(char name[],Addresbook*addresbook)
{
    int i=0,found=0,index=1,count=0;
     int edit_index[100];
     while(name[i]!='\0')
    {
        name[i]=tolower((unsigned char)name[i]);//cover to lower case.

        i++;
    }
    for(i=0;i<addresbook->contactcount;i++)
    {
        if(strcmp(name,addresbook->contacts[i].name)==0)//camper the give name with other name in contact and print the give names which is in contact.
        {
            printf("index: %d - %s\t\t%s\t\t%s\n",index++,addresbook->contacts[i].name,addresbook->contacts[i].number,addresbook->contacts[i].email);
            edit_index[count]=i;//creating an array which save a index of names.
            count++;
        }
    }
    if(count==0)
        {
            return 0;
        }
    printf("Enter the index: ");
    scanf("%d",&index);
    index=index-1;//Entered index is sub by 1.
    if(index>=0&&index<count)//if enterde index is camperd by 0 and count value.
    {
        i=edit_index[index];
        printf("%s\t\t%s\t\t%s",addresbook->contacts[i].name,addresbook->contacts[i].number,addresbook->contacts[i].email);//printed a enterd inedx name,numer and email.
    }
    else
    {
     return 0;
    }
    return 1;
}
int searchnumber(char number[],Addresbook*addresbook)
{
    int i,found=0;
    for(i=0;i<addresbook->contactcount;i++)
    {
    if(strcmp(number,addresbook->contacts[i].number)==0)//camper the entered number is present are not.
    {
        printf("%s\t\t%s\t\t%s\n",addresbook->contacts[i].name,addresbook->contacts[i].number,addresbook->contacts[i].email);//if numer is present printed number.
        found=1;
        break;
    }
     if(found==0)//if number is not there it print a error message.
    {
        return 0;
    }
    }
    return 1;

}
int searchemail(char email[],Addresbook*addresbook)
{
    int i=0,found=0;
     while(email[i]!='\0')
    {
        email[i]=tolower((unsigned char)email[i]);//conver to lower case.

        i++;
    }
    for(i=0;i<addresbook->contactcount;i++)
    {
    if(strcmp(email,addresbook->contacts[i].email)==0)// camper the email with a other email of contact if the email is there it printed the contact.
    {
        printf("%s\t%s\t%s\n",addresbook->contacts[i].name,addresbook->contacts[i].number,addresbook->contacts[i].email);
        found=1;
        break;
    }
    }
    if(found==0)//if the email is not present is contact it print error message.
    {
        return 0;
    }
    return 1;

}
int editname(char name[],Addresbook*addresbook)
{
int i=0,count=0,index=1,found=0;
char Newname[100];
int selected_index;
int edit_index[100];
    while(name[i]!='\0')
    {
        name[i]=tolower((unsigned char)name[i]);

        i++;
    }
    for(i=0;i<addresbook->contactcount;i++)
    {
        if(strcmp(name,addresbook->contacts[i].name)==0)//camper the name with other name in contact which name is equle to enter name is printed here.
        {
            printf("index: %d - %s\t\t%s\t\t%s\n",index++,addresbook->contacts[i].name,addresbook->contacts[i].number,addresbook->contacts[i].email);
            edit_index[count]=i;
            count++;
        }
    }
    if(count==0)
        {
            return 0;
        }
    printf("Enter the index: ");
    scanf("%d",&index);//Enter the idex of which name is wanted to edit name .
    index=index-1;
    if(index>=0&&index<count)
    {
        selected_index=edit_index[index];
    }
    else
    {
        return 0;
    }
        printf("Enter a new name: ");//enter the new name.
        scanf(" %99[^\n]", Newname);


        strcpy(addresbook->contacts[selected_index].name, Newname);//compy  new name to which we want to edit.

        printf("New name updated successfully\n");
        return 1;
}
int editnumber(char number[],Addresbook*addresbook)
{
    int i,found=0,index;
    for(i=0;i<addresbook->contactcount;i++)
    {
    if(strcmp(number,addresbook->contacts[i].number)==0)//camper the number to other number other number in contact which is equle to the number is printed.
    {
        printf("%s\t%s\t%s\n",addresbook->contacts[i].name,addresbook->contacts[i].number,addresbook->contacts[i].email);
        index=i;
        found=1;
        break;
    }
    }
    if(found==0)
    {
        return 0;
    }
    while(1)
    {
    printf("Enter the new number: ");
    scanf(" %[^\n]",number);//enter the new number.
    found=0;
    for(i=0;i<addresbook->contactcount;i++)
    {
    if(i!=index &&strcmp(number,addresbook->contacts[i].number)==0)//camper the new number to othe which is equle to other number if it equle it give a error message.
    {
        printf("you enter number is alread exit try again\n");
        found= 1;
    }
    }
    if(found==1)
    {
        continue;
    }
    strcpy(addresbook->contacts[index].number,number);//copy a new number.
    printf("New number is updated successfully");
    return 1;
}

}
int editemail(char email[],Addresbook*addresbook)
{
    int i=0,found=0,index;
    while(email[i]!='\0')
    {
        email[i]=tolower((unsigned char)email[i]);

        i++;
    }
    for(i=0;i<addresbook->contactcount;i++)
    {
    if(strcmp(email,addresbook->contacts[i].email)==0)//camper the email to other email in contact.
    {
        printf("%s\t%s\t%s\n",addresbook->contacts[i].name,addresbook->contacts[i].number,addresbook->contacts[i].email);
        index=i;
        found=1;
        break;
    }
    }
    if(found==0)
    {
        return 0;
    }
    while(1)
    {
    printf("Enter the new email: ");
    scanf(" %[^\n]",email);//enter the new email.
    found=0;
    for(i=0;i<addresbook->contactcount;i++)
    {
    if(i!=index &&strcmp(email,addresbook->contacts[i].email)==0)//camper the new email is equle to other email in contact.
    {
        printf("you enter email is alread exit try again\n");
        found= 1;
    }
    }
    if(found==1)
    {
        continue;
    }
    strcpy(addresbook->contacts[index].email,email);//copy a new email to a contact.
    printf("New email is updated successfully");
    return 1;
}

}
int deletname(char name[],Addresbook*addresbook)
{
int i=0,count=0,index=1,j;
int edit_index[100];
    while(name[i]!='\0')
    {
        name[i]=tolower((unsigned char)name[i]);

        i++;
    }
    for(i=0;i<addresbook->contactcount;i++)
    {
        if(strcmp(name,addresbook->contacts[i].name)==0)//camper the enter name whith other name in contact if it is equle to other name in contact it printed.
        {
            printf("index: %d - %s\t\t%s\t\t%s\n",index++,addresbook->contacts[i].name,addresbook->contacts[i].number,addresbook->contacts[i].email);
            edit_index[count]=i;
            count++;
        }
    }
    if(count==0)
        {
            return 0;
        }
    printf("Enter the index: ");
    scanf("%d",&index);
    index=index-1;
    if(index>=0&&index<count)
    {
        i=edit_index[index];
    }
    else
    {
        return 0;
    }
     for(j = i; j < addresbook->contactcount - 1; j++)//deteted the give contact and dicreses the caontact size.
    {
        addresbook->contacts[j] = addresbook->contacts[j + 1];
    }

    addresbook->contactcount--;//dicreses the contctcount.

    printf("Contact deleted successfully.\n");
    return 1;
}
int deletnumber(char number[],Addresbook*addresbook)
{
    int i,found=0,index,j;
    for(i=0;i<addresbook->contactcount;i++)
    {
    if(strcmp(number,addresbook->contacts[i].number)==0)//camper the enter number whith other number in contact and printed.
    {
        printf("%s\t%s\t%s\n",addresbook->contacts[i].name,addresbook->contacts[i].number,addresbook->contacts[i].email);
        index=i;
        found=1;
        break;
    }
    }
    if(found==0)
    {
        return 0;
    }
    for(j = index; j < addresbook->contactcount - 1; j++)
    {
        addresbook->contacts[j] = addresbook->contacts[j + 1];//shifted a caontct.
    }

    addresbook->contactcount--;//dicreses the contact count.

    printf("Contact deleted successfully.\n");
    return 1;
}
int deletmail(char email[],Addresbook*addresbook)
{
   int i=0,found=0,index,j;
    while(email[i]!='\0')
    {
        email[i]=tolower((unsigned char)email[i]);

        i++;
    }
    for(i=0;i<addresbook->contactcount;i++)
    {
    if(strcmp(email,addresbook->contacts[i].email)==0)//camper the enter email whith other email in contact and printed.
    {
        printf("%s\t%s\t%s\n",addresbook->contacts[i].name,addresbook->contacts[i].number,addresbook->contacts[i].email);
        index=i;
        found=1;
        break;
    }
    }
    if(found==0)
    {
        return 0;
    } 
    for(j = index; j < addresbook->contactcount - 1; j++)
    {
        addresbook->contacts[j] = addresbook->contacts[j + 1];//shifted a caontct.
    }

    addresbook->contactcount--;//dicreses the contact count.

    printf("Contact deleted successfully.\n");
    return 1;
}
void savecontact(Addresbook*addresbook)
{
    FILE*fp;
    int i;
    fp=fopen("contact.csv","w");
    fprintf(fp,"%d\n",addresbook->contactcount);//printed a contct count.
    for(i=0;i<addresbook->contactcount;i++)
    {
        fprintf(fp,"%s,%s,%s\n",addresbook->contacts[i].name,addresbook->contacts[i].number,addresbook->contacts[i].email);//save the contact in a file.
    }
}